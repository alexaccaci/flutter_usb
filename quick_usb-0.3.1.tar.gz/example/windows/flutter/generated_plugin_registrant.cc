//
//  Generated file. Do not edit.
//

#include "generated_plugin_registrant.h"

#include <quick_usb/quick_usb_plugin.h>

void RegisterPlugins(flutter::PluginRegistry* registry) {
  QuickUsbPluginRegisterWithRegistrar(
      registry->GetRegistrarForPlugin("QuickUsbPlugin"));
}
