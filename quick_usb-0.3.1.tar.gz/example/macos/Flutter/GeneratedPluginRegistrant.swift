//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import quick_usb

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  QuickUsbPlugin.register(with: registry.registrar(forPlugin: "QuickUsbPlugin"))
}
