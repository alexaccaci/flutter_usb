#include "include/quick_usb/quick_usb_plugin.h"

void QuickUsbPluginRegisterWithRegistrar(
    FlutterDesktopPluginRegistrarRef registrar) {
}
