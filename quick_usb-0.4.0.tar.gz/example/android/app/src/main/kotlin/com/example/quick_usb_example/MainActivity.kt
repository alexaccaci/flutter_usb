package com.example.quick_usb_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
