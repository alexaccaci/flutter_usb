#include "include/quick_usb/quick_usb_plugin.h"

void quick_usb_plugin_register_with_registrar(FlPluginRegistrar* registrar) {
}
